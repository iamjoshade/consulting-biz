<?php if(!defined('FW')) die('forbidden');

$custom_class = $atts['custom_class'];

?>

     
    <div class="container">
            <div class="row">
            <?php $args = array(
                'post_type' => 'post',
                'posts_per_page' => 2,
                'order_by' => 'ASC',
            );?>

                    <?php $post =  new WP_Query($args); while ($post->have_posts()): $post->the_post(); ?>
                <div class="col-xl-6 col-lg-6 col-md-6">
                    <div class="home-blog-single mb-30">
                        <div class="blog-img-cap">
                            <div class="blog-img">
                            <?php the_post_thumbnail(); ?>
                                <ul>
                                    <li>By <?php the_author();?>   -   <?php echo get_the_date();?></li>
                                </ul>
                            </div>
                            <div class="blog-cap">
                                <h3><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                                <p><?php the_excerpt();?></p>
                                <a href="<?php the_permalink();?>" class="more-btn"><?php _e('Read more', 'consulting-biz');?></a>
                            </div>
                        </div>
                    </div>
                </div>
        <?php endwhile;  wp_reset_postdata(); ?>
            </div>
        </div>