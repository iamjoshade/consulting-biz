<?php get_header();?>

<main>
    <!--? Hero Start -->
    <div class="slider-area2">
        <div class="slider-height2 hero-overly2 d-flex align-items-center">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="hero-cap hero-cap2 text-center">
                            <h2><?php the_archive_title();?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->


<section class="blog_area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0">
                <div class="blog_left_sidebar">
                    <?php if (have_posts()) :?>
                    <?php while (have_posts()): the_post(); ?>

                    <?php get_template_part( 'partials/content-excerpt');?>

                    <?php endwhile; endif;?>

                    <nav class="blog-pagination justify-content-center d-flex">
                        <?php con_number_pagination(); ?>
                    </nav>

                </div>
            </div>
            <?php get_sidebar();?>
        </div>
    </div>
</section>

<?php get_footer();?>