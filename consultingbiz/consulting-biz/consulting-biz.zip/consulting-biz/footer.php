</main>
<footer>
    <!--? Footer Start-->
    <div class="footer-area section-bg" data-background="<?php echo get_template_directory_uri()?>/assets/img/gallery/footer_bg.jpg">
        <div class="container">
            <div class="footer-top footer-padding">
                <div class="row d-flex justify-content-between">
                    <div class="col-xl-3 col-lg-4 col-md-5 col-sm-8">
                    <?php if (is_active_sidebar('con_footer_widget')) {
                        dynamic_sidebar('con_footer_widget');
                    }?>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-3 col-sm-5">
                        
                    <?php if (is_active_sidebar('con_footer_widget-2')) {
                        dynamic_sidebar('con_footer_widget-2');
                    }?>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-3 col-sm-5">
                    <?php if (is_active_sidebar('con_footer_widget-3')) {
                        dynamic_sidebar('con_footer_widget-3');
                    }?>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-8">
                    <?php if (is_active_sidebar('con_footer_widget-4')) {
                        dynamic_sidebar('con_footer_widget-4');
                    }?>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="row d-flex justify-content-between align-items-center">
                    <div class="col-xl-9 col-lg-8">
                        <div class="footer-copy-right">
                            <p><?php echo get_theme_mod('con_footer_copyright_text');?></p>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-4">
                        <!-- Footer Social -->
                        <div class="footer-social f-right">
                        <?php if(get_theme_mod('con_facebook_handle')) :?>  
                            <a href="<?php echo get_theme_mod('con_facebook_handle');?>"><i class="fab fa-facebook-f"></i></a>
                            <?php endif;?>
                        <?php if(get_theme_mod('con_twitter_handle')) :?>
                            <a href="<?php echo get_theme_mod('con_twitter_handle')?>"><i class="fab fa-twitter"></i></a>
                        <?php endif;?>
                        <?php if(get_theme_mod('con_linkedIn_handle')) :?>
                            <a href="<?php echo get_theme_mod('con_linkedIn_handle')?>"><i class="fab fa-linkedin-in"></i></a>
                            <?php endif;?>
                            <?php if(get_theme_mod('con_instagram_handle')) :?>
                            <a href="<?php echo get_theme_mod('con_instagram_handle');?>"><i class="fab fa-instagram"></i></a>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
</footer>
<!-- Scroll Up -->
<div id="back-top" >
    <a title="Go to Top" href="#"> <i class="fas fa-level-up-alt"></i></a>
</div>

<?php wp_footer();?>
 </body>
 </html>