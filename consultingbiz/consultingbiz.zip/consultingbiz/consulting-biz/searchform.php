<?php $unique_id = esc_attr( uniqid( 'search-form-' ) ); ?>

<form role="search" method="get" class="search-form"
      action="<?php echo esc_url( home_url( '/' ) ); ?>">
<div class="form-group">
    <div class="input-group mb-3">
        <input type="text" class="form-control" name="s" id="<?php echo $unique_id; ?>"
        placeholder='Search Consulting Biz'
        placeholder="<?php _e( 'Search Consulting Biz', 'consulting-biz' ); ?>"/>
        <div class="input-group-append">
        <button class="btns" type="button"><i class="ti-search"></i></button>
        </div>
    </div>
</div>
<button class="button rounded-0 primary-bg text-white w-100 btn_1 boxed-btn"
    type="submit">Search</button>
</form>