<?php if (!defined('FW')) {
	die('Forbidden');
}

$options = array(
	'demo' => array(
		'title'   => __('Slider Options', 'consulting-biz'),
		'type'    => 'tab',

		'options' => array(
			'slider_h1' => array(
				'label' => __('Slider H1 Content', 'consulting-biz'),
				'type'  => 'text',
			),

			'slider_P' => array(
				'label' => __('Slider P Content', 'consulting-biz'),
				'type'  => 'text',
			),

			'slider_btn_text' => array(
				'label' => __('Slider Btn Text', 'consulting-biz'),
				'type'  => 'text',
			),

			'slider_btn_url' => array(
				'label' => __('Slider Btn Url', 'consulting-biz'),
				'type'  => 'text',
			),
			
		),


		
	),
);
