<?php

/** Slider Custom Post Type**/ 
function slider_posttype() {
    $args = array(
        'public'    => true,
        'label'     => ( 'Slider'),
        'menu_icon' => 'dashicons-images-alt',
        "supports" => [ "title", "thumbnail" ],
    );
    register_post_type( 'slider', $args );
}
add_action( 'init', 'slider_posttype' );











