<?php if(!defined('FW')) die('forbidden');


$cfg = array(
    'page_builder' => array(
        'title' => __('Section Heading', 'unyson'),
        'tab'   => __('Content Elements', 'FW'),
        'disable_correction' => true,
    )
);

$cfg['disable_correction'] = false;