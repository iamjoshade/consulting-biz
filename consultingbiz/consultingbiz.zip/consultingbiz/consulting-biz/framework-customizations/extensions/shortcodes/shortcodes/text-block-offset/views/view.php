<?php if (!defined('FW')) die('forbidden');
$main_content = $atts['main_content'];
?>


<?php foreach ($main_content as $key => $page_content_val) : ?>
<div class="offset-xl-1 col-lg-8">
    <div class="about-details-cap mb-50">
      <?php echo $page_content_val['page_main_content'];?>
    </div>
</div>
<?php endforeach;?>