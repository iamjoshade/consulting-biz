<?php 

function con_social_customizer_section($wp_customize){

    $wp_customize->add_setting('con_show_header',[
        'default'            => 'yes',
        'type' 				 => 'theme_mod',
        'transport'          => 'postMessage',
        'sanitize_callback'  => 'con_slug_sanitize_checkbox'
    ]);

    $wp_customize->add_setting( 'con_facebook_handle', array(
        'default'                   =>  '',
        'sanitize_callback'         => 'sanitize_text_field',
        'type' 				        => 'theme_mod',
    ));

    $wp_customize->add_setting( 'con_twitter_handle', array(
        'default'                   =>  '',
        'type' 				        => 'theme_mod',
        'sanitize_callback'         => 'sanitize_text_field'
    ));

    $wp_customize->add_setting( 'con_linkedIn_handle', array(
        'default'                   =>  '',
        'type' 				        => 'theme_mod',
        'sanitize_callback'         => 'sanitize_text_field'
    ));

    $wp_customize->add_setting( 'con_instagram_handle', array(
        'default'                   =>  '',
        'type' 				        => 'theme_mod',
        'sanitize_callback'         => 'sanitize_text_field'
    ));

    $wp_customize->add_setting( 'con_opening_time', array(
        'default'                   =>  '',
        'type' 				        => 'theme_mod',
        'sanitize_callback'         => 'sanitize_text_field'
    ));

    $wp_customize->add_setting( 'con_closed_days', array(
        'default'                   =>  '',
        'type' 				        => 'theme_mod',
        'sanitize_callback'         => 'sanitize_text_field'
    ));


    $wp_customize->add_section( 'con_social_section', array(
        'title'                     =>  __( 'Consulting Biz Social Settings', 'consulting-biz' ),
        'priority'                  =>  30,
        'panel'                     => 'consulting'
    ));


    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_show_header_input',
        array(
            'label'                 =>  __( 'Show Social Media, Opening time & Closing time', 'consulting-biz' ),
            'section'               => 'con_social_section',
            'settings'              => 'con_show_header',
            'type'                  =>  'checkbox',
            'choices'               => [
                'yes'               => 'Yes'
            ],

            
        )
    ));

    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_social_facebook_input',
        array(
            'label'                 =>  __( 'Facebook Handle', 'consulting-biz' ),
            'section'               => 'con_social_section',
            'settings'              => 'con_facebook_handle',
            
        )
    ));

    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_social_twitter_input',
        array(
            'label'                 =>  __( 'Twitter Handle', 'consulting-biz' ),
            'section'               => 'con_social_section',
            'settings'              => 'con_twitter_handle',
        )
    ));

    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_social_linkedIn_input',
        array(
            'label'                 =>  __( 'LinkedIn Profile', 'consulting-biz' ),
            'section'               => 'con_social_section',
            'settings'              => 'con_linkedIn_handle',
        )
    ));

    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_social_instagram_input',
        array(
            'label'                 =>  __( 'Instagram Handle', 'consulting-biz' ),
            'section'               => 'con_social_section',
            'settings'              => 'con_instagram_handle',
        )
    ));

    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_opening_time_input',
        array(
            'label'                 =>  __( 'Opening Time', 'consulting-biz' ),
            'section'               => 'con_social_section',
            'settings'              => 'con_opening_time',
        )
    ));

    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_closed_day_input',
        array(
            'label'                 =>  __( 'Closed Days', 'consulting-biz' ),
            'section'               => 'con_social_section',
            'settings'              => 'con_closed_days',
        )
    ));

}