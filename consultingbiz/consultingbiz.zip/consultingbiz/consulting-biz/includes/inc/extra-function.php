<?php

function con_number_pagination()
{
    global $wp_query;
    $big = 9999999; // need an unlikely integer
    echo paginate_links(array(
     'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
     'format' => '?paged=%#%',
     'current' => max(1, get_query_var('paged')),
     'total' => $wp_query->max_num_pages));
}

// define the comment_form_submit_button callback
function filter_comment_form_submit_button($submit_button, $args)
{
    // make filter magic happen here...
    $submit_before = '<div class="col-sm-12"><div class="form-group">';
    $submit_after = '</div></div>';
    return $submit_before . $submit_button . $submit_after;
};

// add the filter
add_filter('comment_form_submit_button', 'filter_comment_form_submit_button', 10, 2);


function theme_comment($comment, $args, $depth)
{
    $GLOBALS['comment'] = $comment; ?>

<div class="single-comment justify-content-between d-flex"
    id="comment-<?php comment_ID() ?>">

    <?php
if ($comment->comment_approved == '0') : ?>
    <em>Your comment is awaiting moderation.</em>
    <?php endif; ?>

    <?php edit_comment_link('Edit Comment', '&nbsp;', ''); ?>

    <div class="user justify-content-between d-flex">
        <div class="thumb">
            <?php echo get_avatar('$comment', 60, '', '', ['class' => 'avatar avatar-60 photo avatar-default']); ?>
        </div>
        <div class="desc">
            <p class="comment">
                <?php comment_text(); ?>
            </p>
            <div class="d-flex justify-content-between">
                <div class="d-flex align-items-center">
                    <h5>
                        <?php comment_author(); ?>
                    </h5>
                    <p class="date"><?php comment_date(); ?>
                    </p>
                </div>
                <div class="reply-btn">
                    <?php comment_reply_link(array_merge($args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
                </div>
            </div>
        </div>
    </div>
</div>

    <?php
}


// filter to replace class on reply link
add_filter('comment_reply_link', 'replace_reply_link_class');
function replace_reply_link_class($class){
    $class = str_replace("class='comment-reply-link", "class='btn-reply text-uppercase", $class);
    return $class;
}


/* Register our callback function */
function con_footer_widgets($params) {   
 
    global $footer_widget_num; //Our widget counter variable

    //Check if we are displaying "Footer Sidebar"
     if(isset($params[0]['id']) && $params[0]['id'] == 'sidebar-footer1'){
        $footer_widget_num++;
  $divider = 3; //This is number of widgets that should fit in one row   

        //If it's third widget, add last class to it
        if($footer_widget_num % $divider == 0){
     $class = 'class="last '; 
     $params[0]['before_widget'] = str_replace('class="', $class, $params[0]['before_widget']);
  }

 }

     return $params;
}

/* Add dynamic_sidebar_params filter */
add_filter('dynamic_sidebar_params','con_footer_widgets');


add_filter( 'wpcf7_form_class_attr', 'custom_custom_form_class_attr' );
function custom_custom_form_class_attr( $class ) {
  $class .= ' form-contact contact_form';
  return $class;
} 

