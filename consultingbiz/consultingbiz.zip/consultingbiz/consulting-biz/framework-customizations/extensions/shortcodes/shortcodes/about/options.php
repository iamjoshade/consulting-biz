<?php if(!defined('FW')) die('forbidden');

$options = array(

     'about_heading' => array(
        'label' => __('About Heading Text', 'unyson'),
        'type' => 'text'
    ),


    'about_image' => array(
        'label' => __('About Image', 'unyson'),
        'type' => 'upload'
    ),

    'about_description' => array(
        'label' => __('About Us Description', 'unyson'),
        'type' => 'wp-editor'
    ),

    'about_url_text' => array(
        'label' => __('About Us Url Text', 'unyson'),
        'type' => 'text'
    ),

    'about_link_url' => array(
        'label' => __('About Us Url Link', 'unyson'),
        'type' => 'text'
    ),

    'custom_class' => array(
        'label' => __('Custom Class', 'unyson'),
        'type' => 'text'
    ),
);

