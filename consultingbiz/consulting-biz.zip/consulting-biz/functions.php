<?php

//setup 
define('CON_DEV_MODE', true);

// includes
include(get_theme_file_path('includes/inc/extra-function.php'));
include(get_theme_file_path( 'includes/front/enqueue.php' ));
include(get_theme_file_path('includes/setup.php'));
include(get_theme_file_path('includes/widgets.php'));
include(get_theme_file_path('includes/inc/widgets-extends-class.php'));
include(get_theme_file_path('includes/theme-customizer.php'));
include(get_theme_file_path('includes/customizer/socials.php'));
include(get_theme_file_path('includes/customizer/misc.php'));

// tgm-plugin
require_once get_template_directory() . '/includes/inc/class-tgm-plugin-activation.php';
require_once get_template_directory() . '/includes/inc/required-plugins.php';

// hooks
add_action('wp_enqueue_scripts', 'con_enqueue');
add_action('after_setup_theme', 'con_theme_setup');
add_action('widgets_init', 'con_widgtes');
add_action('customize_register', 'con_customize_register');
