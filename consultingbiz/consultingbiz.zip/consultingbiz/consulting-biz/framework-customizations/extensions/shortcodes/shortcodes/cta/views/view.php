<?php if(!defined('FW')) die('forbidden');


$cta_text = $atts['cta_text'];
$cta_btn_text = $atts['cta_btn_text'];
$cta_btn_url = $atts['cta_btn_url'];
$custom_class = $atts['custom_class'];

?>

     
     <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-xl-7 col-lg-9 col-md-8">
                    <div class="wantToWork-caption wantToWork-caption2">
                        <?php if(!empty($cta_text)):?>
                            <?php echo $cta_text?>
                        <?php endif;?>
                    </div>
                </div>
                <div class="col-xl-2 col-lg-3 col-md-4">
                    <?php if(!empty($cta_btn_text)) :?>
                        <a href="<?php echo $cta_btn_url;?>" class="btn btn-black f-right">
                        <?php echo $cta_btn_text?>
                    </a>
                    <?php endif;?>
                </div>
            </div>
        </div>