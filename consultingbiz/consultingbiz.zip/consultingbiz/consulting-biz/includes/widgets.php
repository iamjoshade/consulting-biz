
<?php

function con_widgtes(){
    register_sidebar([
        'name'              => __('Consulting Biz Widget', 'consulting-biz'),
        'id'                => 'con_sidebar',
        'description'       => __('Sidebar for the theme Consulting Biz', 'consulting-biz'),
        'before_widget'     => '<aside id="%1$s" class="single_sidebar_widget widget %2$s">',
        'after_widget'      => '</aside>',
        'before_title'      => '<h4 class="widget_title">',
        'after_title'       => '</h4>'
    ]);


    register_sidebar([
        'name'              => __('Footer Widget 1', 'consulting-biz'),
        'id'                => 'con_footer_widget',
        'description'       => __('Footer Widget For Consulting Biz', 'consulting-biz'),
        'before_widget'     => '<div id="%1$s" class="single-footer-caption mb-50 widget %2$s">',
        'after_widget'      => '</div>',
        'before_title'      => '<h4 class="widget_title">',
        'after_title'       => '</h4>'
    ]);

    register_sidebar([
        'name'              => __('Footer Widget 2', 'consulting-biz'),
        'id'                => 'con_footer_widget-2',
        'description'       => __('Footer Widget For Consulting Biz', 'consulting-biz'),
        'before_widget'     => '<div id="%1$s" class="single-footer-caption mb-50 widget %2$s"><div class="footer-tittle">',
        'after_widget'      => '</div></div>',
        'before_title'      => '<h4>',
        'after_title'       => '</h4>'
    ]);

    register_sidebar([
        'name'              => __('Footer Widget 3', 'consulting-biz'),
        'id'                => 'con_footer_widget-3',
        'description'       => __('Footer Widget For Consulting Biz', 'consulting-biz'),
        'before_widget'     => '<div id="%1$s" class="single-footer-caption mb-50 widget %2$s"><div class="footer-tittle">',
        'after_widget'      => '</div></div>',
        'before_title'      => '<h4>',
        'after_title'       => '</h4>'
    ]);

    register_sidebar([
        'name'              => __('Footer Widget 4', 'consulting-biz'),
        'id'                => 'con_footer_widget-4',
        'description'       => __('Footer Widget For Consulting Biz', 'consulting-biz'),
        'before_widget'     => '<div id="%1$s" class="single-footer-caption mb-50 widget %2$s"><div class="footer-tittle">',
        'after_widget'      => '</div></div>',
        'before_title'      => '<h4>',
        'after_title'       => '</h4>'
    ]);
}