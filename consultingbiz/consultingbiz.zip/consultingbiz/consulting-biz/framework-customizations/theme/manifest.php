<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['id'] = 'scratch';

$manifest['supported_extensions'] = array(
	'page-builder' => array(),
	'backups' => array(),
	// 'slider' => array(),
	// 'styling' => array(),
	// 'breadcrumbs' => array(),
	// 'events' => array(),
	// 'feedback' => array(),
	// 'learning' => array(),
	// 'megamenu' => array(),
	// 'portfolio' => array(),
	// 'sidebars' => array(),
);
