<?php if(!defined('FW')) die('forbidden');

$options = array(
    'section_heading' => array(
        'Label' => __('Heading','consulting-biz'),
        'type'  => 'text'
    ),

    'custom_class' => array(
        'Label' => __('Custom Class','consulting-biz'),
        'type'  => 'text'
    )
);