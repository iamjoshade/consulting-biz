<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'custom_class' => array(
		'label' => __('Custom Class', 'fw'),
		'desc'  => __('Custom CSS Class Name', 'fw'),
		'type'  => 'text',
	),
);