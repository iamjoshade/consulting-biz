<?php if(!defined('FW')) die('forbidden');

$cfg = array(

    'page_builder' => array(
        'title' => __('Recent Blog Post', 'consulting-biz'), 
        'tab'   => __('Content Elements', 'consulting-biz'),
        
    ),

);

