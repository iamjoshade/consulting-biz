<!doctype html>
<html class="no-js" <?php language_attributes();?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head();?>
    <?php echo get_theme_mod('con_google_anaysis');?>
</head>

<body <?php body_class('body-bg');?>>
 

 <?php if(get_theme_mod('con_preloader')):?>
    <!-- Preloader Start  -->
 <div id="preloader-active">
     <div class="preloader d-flex align-items-center justify-content-center">
        <div class="preloader-inner position-relative">
            <div class="preloader-circle"></div>
            <div class="preloader-img pere-text">
                <img src="<?php echo get_theme_mod('con_page_loader_logo')?>" alt="<?php echo bloginfo('name');?>">
            </div>
        </div>
    </div>
 <?php endif;?>
</div>
<header>
    <!-- Header Start -->
    <div class="header-area">
        <div class="main-header">
                    <?php if(get_theme_mod('con_show_header')):?>
                        <div class="header-top d-none d-lg-block">
                            <div class="container">
                                <div class="col-xl-12">
                                    <div class="row d-flex justify-content-between align-items-center">
                                        <div class="header-info-left">
                                            <ul>
                                                <?php if(get_theme_mod('con_opening_time')):?>
                                                <li><i class="far fa-clock"></i> <?php echo get_theme_mod('con_opening_time')?></li>
                                                <?php endif;?>
                                                <?php if(get_theme_mod('con_closed_days')):?>
                                                <li><?php echo get_theme_mod('con_closed_days');?></li>
                                                <?php endif;?>
                                            </ul>
                                        </div>
                                        <div class="header-info-right">
                                            <ul class="header-social">  
                                                <?php if(get_theme_mod('con_facebook_handle')) :?>  
                                                <li><a href="<?php echo get_theme_mod('con_facebook_handle');?>"><i class="fab fa-facebook-f"></i></a></li>
                                                <?php endif;?>
                                                <?php if(get_theme_mod('con_twitter_handle')) :?>
                                                <li><a href="<?php echo get_theme_mod('con_twitter_handle');?>"><i class="fab fa-twitter"></i></a></li>
                                                <?php endif;?>
                                                <?php if(get_theme_mod('con_linkedIn_handle')):?>
                                                <li><a href="<?php echo get_theme_mod('con_linkedIn_handle')?>"><i class="fab fa-linkedin-in"></i></a></li>
                                                <?php endif;?>
                                                <?php if(get_theme_mod('con_instagram_handle')):?>
                                                <li> <a href="<?php echo get_theme_mod('con_instagram_handle')?>"><i class="fab fa-instagram"></i></a></li>
                                                <?php endif;?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                <?php endif;?>                    
            <div class="header-bottom  header-sticky">
                <div class="container">
                    <div class="row align-items-center">
                        <!-- Logo -->
                        <div class="col-xl-2 col-lg-2">
                            <div class="logo">
                                <?php if(has_custom_logo()) :?>
                                    <?php the_custom_logo()?>
                                <?php else:?>
                                    <a href="<?php echo home_url('/');?>"><h2 class="medium"><?php bloginfo('title')?></h2></a>
                                <?php endif;?>
                            </div>
                        </div>
                        <div class="col-xl-10 col-lg-10">
                            <div class="menu-wrapper  d-flex align-items-center justify-content-end">
                                <!-- Main-menu -->
                                  <nav>
                                  <?php if(has_nav_menu( 'primary' )){
                                        wp_nav_menu(array(
                                            'theme_location' => 'primary',
                                            'depth'          => 2,
                                            'menu_id'        => 'navigation',
                                            'container_class'   => 'main-menu d-none d-lg-block'
                                        ));
                                    } elseif(current_user_can('administrator'))  {
                                        print '<span class="add-menu-text">' . esc_html__( 'Please Register Menu From', 'consulting-biz' ) . '<a href="' . esc_url( admin_url( 'nav-menus.php' ) ) . '" target="_blank">' . esc_html__( ' Appearance &gt; Menus', 'consulting-biz' ) . '</a></span>';
                                    }?>
                                  </nav>
                            </div>
                        </div> 
                        <!-- Mobile Menu -->
                        <div class="col-12">
                            <div class="mobile_menu d-block d-lg-none"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->
</header>

<main>