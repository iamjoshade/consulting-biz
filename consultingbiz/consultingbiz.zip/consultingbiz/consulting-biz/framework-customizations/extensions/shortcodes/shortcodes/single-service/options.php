<?php if(!defined('FW')) die('forbidden');

$options = array(
     'service_title' => array(
        'label' => __('Service Title', 'unyson'),
        'type' => 'text'
    ),

    'service_description' => array(
        'label' => __('Service Description', 'unyson'),
        'type' => 'wp-editor'
    ),

    'custom_class' => array(
        'label' => __('Custom Class', 'unyson'),
        'type' => 'text'
    ),
);

