This is an example of a disabled shortcode. The disabling is done via the `fw_ext_shortcodes_disable_shortcodes` filter (see [here](https://github.com/ThemeFuse/Scratch-Theme/blob/master/scratch-parent/framework-customizations/extensions/shortcodes/hooks.php)).

