<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'text' => array(
		'label'   => __('Text', 'consulting-biz'),
		'desc'    => __('Write some text', 'consulting-biz'),
		'type'    => 'textarea',
	),
	'text_color' => array(
		'label'   => __('Color', 'consulting-biz'),
		'desc'    => __('Choose the text color', 'consulting-biz'),
		'type'    => 'select',
		'choices' => array(
			'red'   => __('Red', 'consulting-biz'),
			'green' => __('Green', 'consulting-biz'),
			'blue'  => __('Blue', 'consulting-biz')
		)
	)
);