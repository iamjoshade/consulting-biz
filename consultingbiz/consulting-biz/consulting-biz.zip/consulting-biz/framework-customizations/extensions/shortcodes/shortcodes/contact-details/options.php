<?php if(!defined('FW')) die('forbidden');

$options = array(

     'contact_address' => array(
        'label' => __('Enter Contact Address', 'consulting-biz'),
        'type' => 'text'
    ),

     'contact_address_post_code' => array(
        'label' => __('Address Post Code', 'consulting-biz'),
        'type' => 'text'
    ),

     'telphone_number' => array(
        'label' => __('Enter Phone Number', 'consulting-biz'),
        'type' => 'text'
    ),

     'telphone_working_hours' => array(
        'label' => __('Enter Phone Hours', 'consulting-biz'),
        'type' => 'text'
    ),

     'support_email' => array(
        'label' => __('Enter support email address', 'consulting-biz'),
        'type' => 'text'
    ),

      'support_text' => array(
        'label' => __('Enter support text details', 'consulting-biz'),
        'type' => 'text'
    ),
    

    'custom_class' => array(
        'label' => __('Custom Class', 'consulting-biz'),
        'type' => 'text'
    ),
);

