<?php if(post_password_required( )){
 return;   
}?>

<div class="comments-area">

<?php if(have_comments()):?>

  <h4><?php comments_number()?></h4>

  <?php wp_list_comments(array('callback'=>'theme_comment'));?>
  
    <?php the_comments_pagination(); endif;?>

  <div class="clear"></div>

  <!-- Comment Form ============================================= -->
        

  <?php comment_form([

   

    'comment_field' => '<div class="col-sm-12"><div class="form-group">
                        <textarea name="comment" cols="30" rows="9" class="form-control w-100" placeholder="Write Comments"></textarea>
                        </div></div>',

    
    'fields'        => [

          'author'          =>   '<div class="col-sm-12"><div class="form-group">
                                  <input type="text" name="author" class="form-control" placeholder="Your Name"/>
                                </div></div>',
                                
                                
                            
          'email'           =>   '<div class="col-sm-12"><div class="form-group">
                                    <input type="text" name="email" class="form-control" placeholder="Your Email address" />
                                  </div></div>',


          'url'             =>  '<div class="col-sm-12"><div class="form-group">
                                    <input type="text" name="url" class="form-control" placeholder="Website" />
                                  </div></div>'
    ],
        

      'class_submit'        => 'button button-contactForm btn_1 boxed-btn',
      'label_submit'        => __('Submit Comment', 'consulting-biz'),
      'title_reply'         => __('Leave a <span>Comment</span>', 'consulting-biz') 


  ]);?>





</div><!-- #comments end -->