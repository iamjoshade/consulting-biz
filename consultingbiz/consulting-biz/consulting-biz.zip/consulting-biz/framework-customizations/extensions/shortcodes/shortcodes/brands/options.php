<?php if(!defined('FW')) die('forbidden');

$options = array(

    'brand'              => array(
        'label'         => __('Add Brand', 'consulting-biz'),
        'type'          => 'addable-popup',
         'template'      => '{{- brand_name }}',
        'popup-options' => array(

            'brand_name' => array(
                'label' => __('Brand Name', 'consulting-biz'),
                'type'  => 'text',
            ),

             'brand_image' => array(
                'label' => __('Upload Brand Image', 'consulting-biz'),
                'type'  => 'upload',
            ),

        ),
    ),

    'custom_class' => array(
        'label' => __('Custom Class', 'consulting-biz'),
        'type' => 'text'
    ),
);

