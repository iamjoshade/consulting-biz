<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Demo 2', 'unyson' ),
		'description' => __( 'Demo of a shortcode with options', 'unyson' ),
		'tab'         => __( 'Content Elements', 'fw' ),
	)
);