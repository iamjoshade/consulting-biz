<?php if(!defined('FW')) die('forbidden');

$options = array(
    'custom_class' => array(
        'label' => __('Custom Class', 'consulting-biz'),
        'type' => 'text'
    ),
);

