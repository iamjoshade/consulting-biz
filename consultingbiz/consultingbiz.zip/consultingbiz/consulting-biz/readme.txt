Consulting biz is a html theme from colorlib.com converted to wordpress theme. 

Html Template link: https://colorlib.com/wp/template/consultingbiz/

The Theme is a 5 page website, boostrap ready, and 
with features such as drag and drop functionality, integrated slider, sticky navigation, back to top button, testimonials and animated statistics. Present your team, start a blog, share company logos. etc and its also translation ready.


How to install the theme.

1. Download the theme from https://www.95media.co.uk/free-theme/consulting-biz-wordpress-theme/

2. Upload the download theme to your wordpress website

3. Install the necessary extentions after activating the theme

4. Click->Tools->Demo Content->Install Demo

5. Consulting Biz ready for your business.

6. Gutenberg was disable due to wordpress Version 5.4.1 not compatable with Unyson yet which cause the editor to show in classic editor first. you can enable it back in functions.php line 30
