<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Demo Disabled', 'consulting-biz' ),
		'description' => __( 'Demo of a shortcode that should be disabled', 'consulting-biz' ),
		'tab'         => __( 'Content Elements', 'consulting-biz' ),
	)
);