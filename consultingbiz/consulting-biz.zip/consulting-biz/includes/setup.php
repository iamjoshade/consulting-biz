<?php 

function con_theme_setup(){

    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('custom-logo');
    add_theme_support( 'automatic-feed-links' );
    add_theme_support('html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );

    add_image_size( 'blog-post', 750, 375, array( 'center', 'center' ) );
    add_image_size( 'blog-thumbnail', 80, 80, array( 'center', 'center' ) );

    register_nav_menu( 'primary', __('Primary Menu', 'consulting-biz' ));

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
    }	
    
    if ( ! isset( $content_width ) ) {
        $content_width = 900;
    }


}

function con_replace_submenu_class($menu) {  
    $menu = preg_replace('/ class="sub-menu"/','/ class="submenu" /',$menu);  
    return $menu;  
  }  
  add_filter('wp_nav_menu','con_replace_submenu_class'); 

  //add_filter('use_block_editor_for_post', '__return_false', 10);



 