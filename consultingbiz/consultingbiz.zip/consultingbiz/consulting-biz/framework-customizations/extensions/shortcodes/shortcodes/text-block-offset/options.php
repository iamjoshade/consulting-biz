<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'main_content'             => array(
        'label'         => __('Add Page Content', 'unyson'),
        'type'          => 'addable-popup',
         'template'      => '',
        'popup-options' => array(

              'page_main_content' => array(
                'label' => __('Write Content Below:', 'unyson'),
                'type'  => 'wp-editor',
            ),
        ),
    ),

);
