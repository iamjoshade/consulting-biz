<?php if(!defined('FW')) die('forbidden');


$cfg = array(
    'page_builder' => array(
        'title' => __('Section Heading', 'consulting-biz'),
        'tab'   => __('Content Elements', 'consulting-biz'),
        'disable_correction' => true,
    )
);

$cfg['disable_correction'] = false;