<?php if(!defined('FW')) die('forbidden');

$options = array(

    'brand'              => array(
        'label'         => __('Add Brand', 'unyson'),
        'type'          => 'addable-popup',
         'template'      => '{{- brand_name }}',
        'popup-options' => array(

            'brand_name' => array(
                'label' => __('Brand Name', 'unyson'),
                'type'  => 'text',
            ),

             'brand_image' => array(
                'label' => __('Upload Brand Image', 'unyson'),
                'type'  => 'upload',
            ),

        ),
    ),

    'custom_class' => array(
        'label' => __('Custom Class', 'unyson'),
        'type' => 'text'
    ),
);

