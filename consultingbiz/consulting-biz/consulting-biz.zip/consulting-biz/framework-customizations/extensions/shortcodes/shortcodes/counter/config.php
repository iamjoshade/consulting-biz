<?php if(!defined('FW')) die('forbidden');

$cfg = array(

    'page_builder' => array(
        'title' => __('Counter Area', 'consulting-biz'), 
        'tab'   => __('Content Elements', 'consulting-biz'),
        
    ),

);

