Consulting biz is a free html theme from colorlib.com converted to Wordpress theme by 95media

Html Template link: https://colorlib.com/wp/template/consultingbiz/

The Theme is a 5 page website, bootstrap ready, and 
with features such as drag and drop functionality, integrated slider, sticky navigation, back to top button, testimonials and animated statistics. Present your team, start a blog, share company logos. etc.

How to install the theme.

1. Download the theme from https://www.95media.co.uk/free-theme/consulting-biz-wordpress-theme/

2. Upload the download theme to your Wordpress website

3. Install the necessary extensions after activating the theme

4. Click->Tools->Demo Content->Install Demo

5. Consulting Biz ready for your business.

6. Gutenberg was disable due to Wordpress Version 5.4.1 not compatible with Unyson yet which cause the editor to show in classic editor first. you can enable it back in functions.php line 30

For theme support please visit: https://www.95media.co.uk/forums/forum/consulting-biz-wordpress-theme-support/

