<?php if(!defined('FW')) die('forbidden');
$counter = $atts['counter'];
?>

      <!-- counter_area  -->
      <div class="container">
            <div class="row justify-content-between">
            <?php foreach($counter as $key => $counter_vals) :?>
                <?php if($counter_vals['counter_active'] == "true") : ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <!-- Counter Up -->
                    <div class="single-counter active text-center">
                        <span class="counter"><?php echo $counter_vals['counter_number'];?></span>
                        <p><?php echo $counter_vals['counter_title'];?></p>
                    </div>
                </div>
                <?php else:?>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                    <!-- Counter Up -->
                    <div class="single-counter text-center">
                        <span class="counter"><?php echo $counter_vals['counter_number'];?></span>
                        <p><?php echo $counter_vals['counter_title'];?></p>
                    </div>
                </div>
                <?php endif;?>
            <?php endforeach;?>
            </div>
        </div>
    <!-- /counter_area  -->

   