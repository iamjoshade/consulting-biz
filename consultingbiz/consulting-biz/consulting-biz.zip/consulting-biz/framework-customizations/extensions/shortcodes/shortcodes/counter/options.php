<?php if(!defined('FW')) die('forbidden');

$options = array(


    'counter'             => array(
		'label'         => __( 'Add Counter', 'consulting-biz' ),
		'type'          => 'addable-popup',
		'template'      => '{{- counter_title }}',
		'popup-options' => array(
			'counter_title'                => array(
				'label' => __( 'Counter Title', 'consulting-biz' ),
				'type'  => 'text',
            ),

            'counter_number'                => array(
				'label' => __( 'Enter Counter Number', 'consulting-biz' ),
				'type'  => 'text',
            ),
            'counter_active'                  => array(
                'label' => __( 'Counter Active', 'consulting-biz' ),
                'type'  => 'checkbox',
                'value' => false,
                'text'  => __( 'Add Active to Counter', 'consulting-biz' ),
            ),
        ),
    ),
   
);

