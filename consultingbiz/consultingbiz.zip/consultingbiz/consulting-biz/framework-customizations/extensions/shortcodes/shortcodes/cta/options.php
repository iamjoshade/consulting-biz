<?php if(!defined('FW')) die('forbidden');

$options = array(

    'cta_text' => array(
        'Label' => __('Cta Text','unyson'),
        'type'  => 'wp-editor'
    ),

    'cta_btn_text' => array(
        'Label' => __('Cta Button Text ','unyson'),
        'type'  => 'text'
    ),

     'cta_btn_url' => array(
        'Label' => __('Cta Button Url','unyson'),
        'type'  => 'text'
    ),

    'custom_class' => array(
        'label' => __('Custom Class', 'unyson'),
        'type' => 'text'
    ),
);

