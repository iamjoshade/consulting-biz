<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'tab'         => __('Layout Elements', 'consulting-biz'),
		'title'       => __('Section', 'consulting-biz'),
		'description' => __('Add a Section', 'consulting-biz'),
		'type'        => 'section', // WARNING: Do not edit this
	)
);

$cfg['disalbe_correction'] = true;




