<?php get_header();?>

    <!--? Hero Start -->
    <div class="slider-area2">
        <div class="slider-height2 hero-overly2 d-flex align-items-center">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="hero-cap hero-cap2 text-center">
                            <h2><?php single_post_title();?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  
<!--================Blog Area =================-->
<section class="blog_area single-post-area section-padding">
         <div class="container">
            <div class="row">
            <?php if (have_posts()) :?>
            <?php while (have_posts()): the_post();  
              global $post;
               $author_ID = $post->post_author;
               $author_URL = get_author_posts_url($author_ID);
               ?> 
               <div class="col-lg-8 posts-list">
                  <div <?php post_class( 'single-post' ); ?> id="post-<?php the_ID(); ?>">
                     <div class="feature-img">
                     <?php
                        if (has_post_thumbnail()):
                            the_post_thumbnail('blog-post', array('class' => 'card-img rounded-0 img-fluid'));
                        else: ?>
                        <img src="<?php echo get_template_directory_uri();?>/assets/img/blog/placeholder-img.jpg"
                            alt="" class="card-img rounded-0 img-fluid">
                        <?php endif;?>
                     </div>
                     <div class="blog_details">
                        <h2><?php the_title();?></h2>
                        <ul class="blog-info-link mt-3 mb-4">
                        <li><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><i class="fa fa-user"></i> <?php the_author();?> &nbsp;| &nbsp;
                                    <?php the_category(', ')?></a>
                            </li>
                            <li><a href="#"><i class="fa fa-comments"></i> <?php comments_number();?></a></li>
                              <?php if( has_tag() ): ?>
                              <li><a href=""><i class="fa fa-tags"></i><?php the_tags('', ',');?></a>
                            <?php endif;?>
                            </li>
                        </ul>
                        <?php the_content();?>
                     </div>
                  </div>
                  <div class="blog-author">
                     <div class="media align-items-center">
                     <?php echo get_avatar($author_ID, 90, '', false, ['class' => 'img-circle']);?>
                        <div class="media-body">
                           <a href="<?php echo $author_URL;?>">
                              <h4><strong><?php the_author();?></strong></h4>
                           </a>
                           <p><?php echo nl2br(get_the_author_meta('description'));?></p>
                        </div>
                     </div>
                  </div>
                  
                  <?php if(comments_open() || get_comments_number()){
                 comments_template();
             }?>

                  
               </div>
            <?php endwhile; endif;?>
            <?php get_sidebar();?>
            </div>
         </div>
      </section>
      <!--================ Blog Area end =================-->

<?php get_footer();
