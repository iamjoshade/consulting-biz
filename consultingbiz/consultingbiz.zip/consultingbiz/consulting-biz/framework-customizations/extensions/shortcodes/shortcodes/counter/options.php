<?php if(!defined('FW')) die('forbidden');

$options = array(

    // Projects Completed
   
    'project_completed_text' => array(
        'label' => __('Projects Completed', 'unyson'),
        'type' => 'text'
    ),

    'project_completed_counter_number' => array(
        'label' => __('Enter Value for project completed', 'unyson'),
        'type' => 'text'
    ),

    // Active Clients

    'active_clients_text' => array(
        'label' => __('Active Clients Text', 'unyson'),
        'type' => 'text'
    ),

    'active_clients_counter_number' => array(
        'label' => __('Enter Value Active Clients', 'unyson'),
        'type' => 'text'
    ),

    // Cups of Coffee

    'cups_of_coffee_text' => array(
        'label' => __('Cups of Coffee Text', 'unyson'),
        'type' => 'text',
    ),

    'cups_of_coffee_counter_number' => array(
        'label' => __('Enter Value for Cups of Coffee Here', 'unyson'),
        'type' => 'text'
    ),

    // Happy Clients

    'happy_clients_text' => array(
        'label' => __('Happy Clients Text', 'unyson'),
        'type' => 'text'
    ),

    'happy_clients_counter_number' => array(
        'label' => __('Enter Value for happy clients here', 'unyson'),
        'type' => 'text',
        'placeholder' => 'enter numbers only'
    ),

    'custom_class' => array(
        'label' => __('Custom Class', 'unyson'),
        'type' => 'text'
    ),
);

