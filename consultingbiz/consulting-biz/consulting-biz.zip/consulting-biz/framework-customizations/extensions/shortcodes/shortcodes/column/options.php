<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'custom_class' => array(
		'label' => __('Custom Class', 'consulting-biz'),
		'desc'  => __('Custom CSS Class Name', 'consulting-biz'),
		'type'  => 'text',
	),
);