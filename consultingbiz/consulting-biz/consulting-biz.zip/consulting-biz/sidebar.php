<div class="col-lg-4">
<div class="blog_right_sidebar">

<?php if (is_active_sidebar('con_sidebar')) {
    dynamic_sidebar('con_sidebar');
}?>

</div>
</div>