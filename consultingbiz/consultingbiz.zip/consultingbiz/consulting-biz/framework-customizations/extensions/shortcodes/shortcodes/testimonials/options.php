<?php if (!defined('FW')) die('forbidden');

$options = array(


    'testimonial'             => array(
        'label'         => __('Add Testimonial', 'unyson'),
        'type'          => 'addable-popup',
         'template'      => '{{- testimonal_author_fullname }}',
        'popup-options' => array(

            'testimonal_details' => array(
                'label' => __('Testimonal Goes Here', 'unyson'),
                'type'  => 'textarea',
            ),


             'testimonial_author_image' => array(
                'label' => __('Upload Testimonal Author Image', 'unyson'),
                'type'  => 'upload',
            ),

             'testimonal_author_fullname' => array(
                'label' => __('Testimonal Author Name', 'unyson'),
                'type'  => 'text',
            ),

             'testimonal_author_postion' => array(
                'label' => __('Testimonal Author Position', 'unyson'),
                'type'  => 'text',
            ),
        ),
    ),

    'custom_class' => array(

        'label' => __('Custom Class', 'unyson'),
        'type' => 'text'

    ),
);
