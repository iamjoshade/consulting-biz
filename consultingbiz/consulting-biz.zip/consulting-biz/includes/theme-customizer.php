<?php

function con_customize_register($wp_customize){

   $wp_customize->add_panel('consulting', [
      'title'           => __('Consulting Biz', 'consulting-biz'),
      'description'     => '<p>Consulting Biz Theme Settings</p>',
      'priority'        => 160
   ]);

   con_social_customizer_section($wp_customize);
   con_misc_customizer_section($wp_customize);
}

