<?php if (!defined('FW')) die('Forbidden'); ?>
<p>View B content</p>
