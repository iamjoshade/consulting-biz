<?php if(!defined('FW')) die('forbidden');


$brand = $atts['brand'];
$custom_class = $atts['custom_class'];

?>

     
       <div class="container">
            <div class="brand-active brand-border pb-40">
                <?php foreach ($brand as $key => $brand_val) : ?>
                <div class="single-brand">
                    <img src="<?php echo $brand_val['brand_image']['url'] ?>" alt="">
                </div>
            <?php endforeach;?>
               
            </div>
        </div>