<?php 
function con_misc_customizer_section($wp_customize){
    

    $wp_customize->add_setting('con_preloader',[
        'default'            => 'yes',
        'type' 				 => 'theme_mod',
        'transport'          => 'postMessage',
        'sanitize_callback'  => 'con_slug_sanitize_checkbox'
    ]);

    $wp_customize->add_setting('con_footer_copyright_text',[
        'default'   => 'Copyrights &copy; 2020 All Rights Reserved.',
        'sanitize_callback'         => 'sanitize_text_field',
    ]);

      $wp_customize->add_setting('con_google_anaysis',[
        'default'                   => '',
        'type' 				        => 'theme_mod',
        'sanitize_callback'         => 'sanitize_textarea_field',
    ]);

    $wp_customize->add_setting('con_page_loader_logo', [
        'default'                   => '',
        'type' 				        => 'theme_mod',
        'sanitize_callback'         => 'esc_url_raw'
    ]);

    $wp_customize->add_section('con_misc_section', [
        'title' => 'Consulting Misc Settings',
        'priority' => 30,
        'panel'    => 'consulting'
    ]);

   
    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_footer_copyright_text_input',
        array(
            'label'                 =>  __( 'Copyright Information', 'consulting-biz' ),
            'section'               => 'con_misc_section',
            'settings'              => 'con_footer_copyright_text',
            'type'                  =>  'text',
            
        )
    ));


    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_show_preload_input',
        array(
            'label'                 =>  __( 'Activate Preloader', 'consulting-biz' ),
            'section'               => 'con_misc_section',
            'settings'              => 'con_preloader',
            'type'                  =>  'checkbox',
            'choices'               => [
                'no'               => 'No'
            ],
        )
    ));

     $wp_customize->add_control(new WP_Customize_Upload_Control(
        $wp_customize,
        'con_preloader_file_input',
        array(
            'label'                 =>  __( 'Upload Preloader Image', 'consulting-biz' ),
            'section'               => 'con_misc_section',
            'settings'              => 'con_page_loader_logo',
        )
    ));


     $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_google_input',
        array(
            'label'                 =>  __( 'Google Analytics Js Code', 'consulting-biz' ),
            'section'               => 'con_misc_section',
            'settings'              => 'con_google_anaysis',
            'type'                  =>  'textarea',
            
        )
    ));


}