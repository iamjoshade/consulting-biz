<?php get_header();?>
<main>
    <!--? Hero Start -->
    <div class="slider-area2">
        <div class="slider-height2 hero-overly2 d-flex align-items-center">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="hero-cap hero-cap2 text-center">
                            <h2><?php _e('Blog', 'consulting-biz');?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->

<!--================Blog Area =================-->
<section class="blog_area section-padding">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 mb-5 mb-lg-0">
                <div class="blog_left_sidebar">
                    <?php if (have_posts()) :?>
                    <?php while (have_posts()): the_post(); ?>
                    <article class="blog_item">
                        <div class="blog_item_img">
                            <?php
                                    if (has_post_thumbnail()):
                                        the_post_thumbnail('blog-post', array('class' => 'card-img rounded-0 img-fluid'));
                                    else: ?>
                            <img src="<?php echo get_template_directory_uri();?>/assets/img/blog/placeholder-img.jpg"
                                alt="" class="card-img rounded-0 img-fluid">
                            <?php endif;?>
                            <a href="" class="blog_item_date">
                                <h3><?php echo esc_html(get_the_date('d'));?>
                                </h3>
                                <p><?php echo esc_html(get_the_date('M'));?>
                                </p>
                            </a>
                        </div>

                        <div class="blog_details">
                            <a class="d-inline-block"
                                href="<?php the_permalink();?>">
                                <h2><?php the_title();?>
                                </h2>
                            </a>
                            <p><?php the_excerpt();?>
                            </p>
                            <ul class="blog-info-link">
                                <li><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><i class="fa fa-user"></i> 
                                        <?php the_author();?>  &nbsp; |  &nbsp; <?php the_category(',')?>
                                    </a>
                                </li>
                                <li><a href="<?php echo get_comments_link();?>"><i class="fa fa-comments"></i> <?php comments_number('0');?></a>
                                </li>
                            </ul>
                        </div>
                    </article>

                    <?php endwhile; endif;?>

                    <nav class="blog-pagination justify-content-center d-flex">
                       
                    <?php the_posts_pagination( array(
			            'prev_text'	=> esc_html__( 'Previous' , 'consulting-biz'),
			            'next_text'	=> esc_html__( 'Next' , 'consulting-biz')
			        ));?>

                    </nav>

                </div>
            </div>
            <?php get_sidebar();?>
        </div>
    </div>
</section>
<!--================Blog Area =================-->
</main>
<?php get_footer();
