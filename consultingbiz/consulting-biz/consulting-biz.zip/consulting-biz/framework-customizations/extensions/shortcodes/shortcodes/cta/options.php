<?php if(!defined('FW')) die('forbidden');

$options = array(

    'cta_text' => array(
        'Label' => __('Cta Text','consulting-biz'),
        'type'  => 'wp-editor'
    ),

    'cta_btn_text' => array(
        'Label' => __('Cta Button Text ','consulting-biz'),
        'type'  => 'text'
    ),

     'cta_btn_url' => array(
        'Label' => __('Cta Button Url','consulting-biz'),
        'type'  => 'text'
    ),

    'custom_class' => array(
        'label' => __('Custom Class', 'consulting-biz'),
        'type' => 'text'
    ),
);

