<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Demo 2', 'consulting-biz' ),
		'description' => __( 'Demo of a shortcode with options', 'consulting-biz' ),
		'tab'         => __( 'Content Elements', 'consulting-biz' ),
	)
);