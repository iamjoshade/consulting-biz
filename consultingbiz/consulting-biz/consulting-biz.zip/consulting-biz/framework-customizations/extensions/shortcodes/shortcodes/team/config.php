<?php if(!defined('FW')) die('forbidden');

$cfg = array(

    'page_builder' => array(
        'title' => __('Team', 'consulting-biz'), 
        'tab'   => __('Content Elements', 'consulting-biz'),
        
    ),

);

