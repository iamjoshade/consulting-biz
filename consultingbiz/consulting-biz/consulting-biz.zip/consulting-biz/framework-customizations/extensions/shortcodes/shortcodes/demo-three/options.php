<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'view' => array(
		'label'   => __('View', 'consulting-biz'),
		'desc'    => __('Choose what view file should the shortcode pick', 'consulting-biz'),
		'type'    => 'select',
		'choices' => array(
			'a'    => __('View A', 'consulting-biz'),
			'b'    => __('View B', 'consulting-biz'),
			'c'    => __('View C', 'consulting-biz'),
			'rand' => __('Random View', 'consulting-biz')
		)
	)
);