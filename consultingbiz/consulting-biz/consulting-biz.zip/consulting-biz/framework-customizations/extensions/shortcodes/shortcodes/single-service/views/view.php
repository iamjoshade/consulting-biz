<?php if (!defined('FW')) die('forbidden');

$service_title          = $atts['service_title'];
$service_description    = $atts['service_description'];
$custom_class           = $atts['custom_class'];


?>


  
<div class="single-cat text-center mb-50">
    <div class="cat-cap">
        <h5><?php echo $service_title;?></h5>
        <p><?php echo $service_description;?></p>
    </div>
</div>