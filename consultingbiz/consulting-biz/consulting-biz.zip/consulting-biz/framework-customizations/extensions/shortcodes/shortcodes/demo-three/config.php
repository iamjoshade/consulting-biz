<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Demo 3', 'consulting-biz' ),
		'description' => __( 'Demo of a shortcode with custom class', 'consulting-biz'),
		'tab'         => __( 'Content Elements', 'consulting-biz' )
	)
);