<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Text Block', 'consulting-biz' ),
	'description' => __( 'Add a Text Block', 'consulting-biz' ),
	'tab'         => __( 'Content Elements', 'consulting-biz' ),
	'disable_correction' => true,
);

$cfg['disable_correction'] = false;