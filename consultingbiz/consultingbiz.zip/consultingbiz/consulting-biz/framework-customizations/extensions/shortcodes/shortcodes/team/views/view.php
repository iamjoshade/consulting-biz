<?php if(!defined('FW')) die('forbidden');

$team = $atts['team'];
$custom_class = $atts['custom_class'];

?>

<div class="row">
<?php foreach ($team as $key => $team_val) : ?>
    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-">
                    <div class="single-team mb-30">
                        <div class="team-img">
                            <img src="<?php echo $team_val['team_image']['url'] ?>" alt="">
                        </div>
                        <div class="team-caption">
                            <h3> <?php echo $team_val['team_name'];?></h3>
                            <span><?php echo $team_val['team_job_title'];?></span>
                        </div>
                    </div>
</div>
<?php endforeach;?>
</div>
          
 