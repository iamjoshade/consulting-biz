<?php if (!defined('FW')) die('forbidden');



$about_heading = $atts['about_heading'];
$about_image = $atts['about_image'];
$about_description = $atts['about_description'];
$about_url_text = $atts['about_url_text'];
$about_link_url = $atts['about_link_url'];
$custom_class = $atts['custom_class'];

?>


<!--? About Area Start-->
<div class="container">
            <div class="row">
                <div class=" col-lg-6">
                    <div class="support-location-img">
                        <?php if(!empty($about_image)) :?>
                            <img src="<?php echo $about_image['url'];?>" alt="<?php echo $about_heading;?>">
                        <?php endif;?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="right-caption">
                        <!-- Section Tittle -->
                        <?php if(!empty($about_heading)) :?>
                        <div class="section-tittle section-tittle2 mb-50">
                            <h2><?php echo $about_heading;?></h2>
                        </div>
                    <?php endif;?>

                     <?php if(!empty($about_description)) :?>
                        <div class="support-caption">
                           <?php echo $about_description;?>
                            <a href="<?php echo $about_link_url;?>" class="btn post-btn"><?php echo $about_url_text;?></a>
                        </div>
                    <?php endif;?>
                    </div>
                </div>
</div>
</div>
    <!-- About Area End-->

  
 