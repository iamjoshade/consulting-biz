<?php if (!defined('FW')) die('Forbidden'); ?>
<p>View A content</p>
