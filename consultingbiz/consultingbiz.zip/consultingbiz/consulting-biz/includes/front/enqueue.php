<?php

function con_enqueue(){

    $uri =  get_theme_file_uri();

    $ver =  CON_DEV_MODE ? time() : false;

    wp_register_style('con-fonts', 'https://fonts.googleapis.com/css?family=Alex+Brush|Roboto:300,400,700,900|Titillium+Web:300,400,600,700&display=swap', [], $ver);
    wp_register_style('con_bootstrap-style', $uri . '/assets/css/bootstrap.min.css', [], $ver);
    wp_register_style('con_carousel-min', $uri . '/assets/css/owl.carousel.min.css', [], $ver);
    wp_register_style('con_slicknav', $uri . '/assets/css/slicknav.css', [], $ver);
    wp_register_style('con_flaticon', $uri . '/assets/css/flaticon.css', [], $ver);
    wp_register_style('con_animate', $uri . '/assets/css/animate.min.css', [], $ver);
    wp_register_style('con_magnific-popup', $uri . '/assets/css/magnific-popup.css', [], $ver);
    wp_register_style('con_fontawesome-all', $uri . '/assets/css/fontawesome-all.min.css', [], $ver);
    wp_register_style('con_themify-icons', $uri . '/assets/css/themify-icons.css', [], $ver);
    wp_register_style('con_slick', $uri . '/assets/css/slick.css', [], $ver);
    wp_register_style('con_nice-select', $uri . '/assets/css/nice-select.css', [], $ver);
    wp_register_style('con_main-style', $uri . '/assets/css/style.css', [], $ver);
    wp_register_style('con_style', $uri . '/style.css', [], $ver);

    wp_enqueue_style('con-fonts');
    wp_enqueue_style('con_bootstrap-style');
    wp_enqueue_style('con_carousel-min');
    wp_enqueue_style('con_slicknav');
    wp_enqueue_style('con_flaticon');
    wp_enqueue_style('con_animate');
    wp_enqueue_style('con_magnific-popup');
    wp_enqueue_style('con_fontawesome-all');
    wp_enqueue_style('con_themify-icons');
    wp_enqueue_style('con_slick');
    wp_enqueue_style('con_nice-select');
    wp_enqueue_style('con_main-style');
    wp_enqueue_style('con_style');

    wp_enqueue_script('jquery');
    wp_register_script('con-modernizr', $uri. '/assets/js/vendor/modernizr-3.5.0.min.js', [], $ver, true);
    wp_register_script('con-popper',  $uri. '/assets/js/popper.min.js', [], $ver, true);
    wp_register_script('con-bootstrap-min',  $uri. '/assets/js/bootstrap.min.js', [], $ver, true);
    wp_register_script('con-slicknav',  $uri. '/assets/js/jquery.slicknav.min.js', [], $ver, true);

    wp_register_script('con-carousel-min',  $uri. '/assets/js/owl.carousel.min.js', [], $ver, true);
    wp_register_script('con-slick',  $uri. '/assets/js/slick.min.js', [], $ver, true);
    wp_register_script('con-wow',  $uri. '/assets/js/wow.min.js', [], $ver, true);
    wp_register_script('con-animated-headline',  $uri. '/assets/js/animated.headline.js', [], $ver, true);
    wp_register_script('con-magnific-popup',  $uri. '/assets/js/jquery.magnific-popup.js', [], $ver, true);
    wp_register_script('con-jquery-nice-select-min',  $uri. '/assets/js/jquery.nice-select.min.js', [], $ver, true);
    wp_register_script('con-sticky',  $uri. '/assets/js/jquery.sticky.js', [], $ver, true);
    wp_register_script('con-waypoints',   'http://cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.3/waypoints.min.js', [], $ver, true);
    wp_register_script('con-counterup', $uri.  '/assets/js/jquery.counterup.min.js', [], $ver, true);
    wp_register_script('con-plugins', $uri.  '/assets/js/plugins.js', [], $ver, true);
    wp_register_script('con-main-js', $uri.  '/assets/js/main.js', [], $ver, true);


    wp_enqueue_script('con-modernizr');
    wp_enqueue_script('con-popper');
    wp_enqueue_script('con-bootstrap-min');
    wp_enqueue_script('con-slicknav');
    wp_enqueue_script('con-carousel-min');
    wp_enqueue_script('con-slick');
    wp_enqueue_script('con-wow');
    wp_enqueue_script('con-animated-headline');
    wp_enqueue_script('con-magnific-popup');
    wp_enqueue_script('con-jquery-nice-select-min');
    wp_enqueue_script('con-sticky');
    wp_enqueue_script('con-waypoints');
    wp_enqueue_script('con-counterup');
    wp_enqueue_script('con-plugins');
    wp_enqueue_script('con-main-js');

    



}