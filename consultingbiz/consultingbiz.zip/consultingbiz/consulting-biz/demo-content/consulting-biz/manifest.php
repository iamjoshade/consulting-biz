<?php if (!defined('FW')) die('Forbidden');
/**
 * @var string $uri Demo directory url
 */

$manifest = array();
$manifest['title'] = __('Consulting Biz Demo', 'consulting-biz');
$manifest['screenshot'] = $uri . '/screenshot.jpg';
$manifest['preview_link'] = 'https://consultingbiz.95media.co.uk';