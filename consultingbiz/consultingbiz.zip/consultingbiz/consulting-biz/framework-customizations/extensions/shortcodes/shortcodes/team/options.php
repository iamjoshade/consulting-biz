<?php if(!defined('FW')) die('forbidden');

$options = array(

    'team'              => array(
        'label'         => __('Add Team', 'unyson'),
        'type'          => 'addable-popup',
         'template'      => '{{- team_name }}',
        'popup-options' => array(

            'team_name' => array(
                'label' => __('Team Name', 'unyson'),
                'type'  => 'text',
            ),

             'team_image' => array(
                'label' => __('Upload Team Image', 'unyson'),
                'type'  => 'upload',
            ),

             'team_job_title' => array(
                'label' => __('Job Title', 'unyson'),
                'type'  => 'text',
            ),

        ),
    ),

    
    'custom_class' => array(
        'label' => __('Custom Class', 'unyson'),
        'type' => 'text'
    ),
);

