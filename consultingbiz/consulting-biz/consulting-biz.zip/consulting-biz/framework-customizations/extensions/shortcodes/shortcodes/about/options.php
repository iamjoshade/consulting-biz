<?php if(!defined('FW')) die('forbidden');

$options = array(

     'about_heading' => array(
        'label' => __('About Heading Text', 'consulting-biz'),
        'type' => 'text'
    ),


    'about_image' => array(
        'label' => __('About Image', 'consulting-biz'),
        'type' => 'upload'
    ),

    'about_description' => array(
        'label' => __('About Us Description', 'consulting-biz'),
        'type' => 'wp-editor'
    ),

    'about_url_text' => array(
        'label' => __('About Us Url Text', 'consulting-biz'),
        'type' => 'text'
    ),

    'about_link_url' => array(
        'label' => __('About Us Url Link', 'consulting-biz'),
        'type' => 'text'
    ),

    'custom_class' => array(
        'label' => __('Custom Class', 'consulting-biz'),
        'type' => 'text'
    ),
);

