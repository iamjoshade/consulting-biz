<?php if(!defined('FW')) die('forbidden');

$cfg = array(

    'page_builder' => array(
        'title' => __('Brands We have Work With', 'unyson'), 
        'tab'   => __('Content Elements', 'FW'),
        
    ),

);

