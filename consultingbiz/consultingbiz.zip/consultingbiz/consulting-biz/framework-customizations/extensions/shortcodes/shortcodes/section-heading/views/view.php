<?php if(!defined('FW')) die('forbidden');

$heading = $atts['section_heading'];
$custom_class = $atts['custom_class'];

?>


    <!-- Section Tittle -->
    <div class="section-tittle <?php echo $custom_class;?>">
        <h2><?php echo $heading;?></h2>
    </div>

