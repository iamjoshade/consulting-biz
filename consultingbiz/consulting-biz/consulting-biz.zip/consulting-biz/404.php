<?php get_header();?>

<main>
<div class="slider-area2">
        <div class="slider-height2 hero-overly2 d-flex align-items-center">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="hero-cap hero-cap2 text-center">
                        <h2><?php _e('Page Not Found', 'consulting-biz')?></h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<section class="404 section-padding">
<div class="container">
            <div class="row"></div>
<div class="heading-block text-center mb-3">
            <h4><?php _e("Ooopps! The Page you were looking for, couldn't be found.", 'consulting-biz')?></h4>
            <span><?php _e("Try searching for the best match or browse the links below:", 'consulting-biz')?></span>
            <?php get_search_form();?>
        </div>

			</div>
</section>

<?php get_footer();?>