<?php if(!defined('FW')) die('forbidden');


$custom_class = $atts['custom_class'];

?>


        
     

<!-- slider Area Start-->
    <div class="slider-area <?php echo $custom_class?>">
        <div class="slider-active">
            <?php $slider = new WP_Query(array('post_type' => 'slider', 'order' => 'ASC', 'posts_per_page'=>'-1')); ?>
             <?php 

                            global $post;

                        while ($slider->have_posts()) : $slider->the_post();

                                $slider_h1 = fw_get_db_post_option($post->ID, 'slider_h1');
                                $slider_P = fw_get_db_post_option($post->ID, 'slider_P');
                                $slider_btn_text = fw_get_db_post_option($post->ID, 'slider_btn_text');
                                $slider_btn_url  = fw_get_db_post_option($post->ID, 'slider_btn_url');

                            ?>
            <!-- Single Slider -->
            <div class="single-slider slider-height d-flex align-items-center"style="background-image: url(<?php echo get_the_post_thumbnail_url(array()); ?>);">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8 col-lg-7 col-md-8">
                            <div class="hero__caption">
                                 <?php if(!empty($slider_h1)) :?>
                                <h1 data-animation="fadeInLeft" data-delay=".5s" ><?php echo $slider_h1?></h1>
                               <?php endif?>
                                <?php if(!empty($slider_P)) :?>
                                <p data-animation="fadeInLeft" data-delay=".9s"><?php echo $slider_P?></p>
                               <?php endif;?>
                                <!-- Hero-btn -->
                                <?php if(!empty($slider_btn_text)) :?>
                                <div class="hero__btn" data-animation="fadeInLeft" data-delay="1.1s">
                                    <a href="<?php echo $slider_btn_url;?>" class="btn hero-btn"><?php echo $slider_btn_text;?></a>
                                </div>
                                <?php endif;?>
                            </div>
                        </div>
                    </div>
                </div>          
            </div>
                 <?php endwhile; wp_reset_postdata();?> 
            </div>
    </div>

    
    <!-- slider Area End-->






 