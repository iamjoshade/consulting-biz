<?php get_header();?>



<?php  while (have_posts()):the_post();?>

<!--? Hero Start -->
<div class="slider-area2"
    style="background-image:url(<?php echo get_the_post_thumbnail_url(array()); ?>);">
    <div class="slider-height2 hero-overly2 d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">
                    <div class="hero-cap hero-cap2 text-center">
                        <h2><?php single_post_title();?>
                        </h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

            <?php the_content();
            
            $defaults = array(
                'before'           => '<p class="text-center">' . __( 'Pages:', 'consulting-biz' ),
                'after'            => '</p>',
                );

                wp_link_pages( $defaults );



                    wp_link_pages();
                 ?>
            
<?php endwhile;?>

<?php get_footer();
