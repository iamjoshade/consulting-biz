<?php if (!defined('FW')) {
	die('Forbidden');
}

$options = array(
	'demo' => array(
		'title'   => __('Slider Options', 'unyson'),
		'type'    => 'tab',

		'options' => array(
			'slider_h1' => array(
				'label' => __('Slider H1 Content', 'unyson'),
				'type'  => 'text',
			),

			'slider_P' => array(
				'label' => __('Slider P Content', 'unyson'),
				'type'  => 'text',
			),

			'slider_btn_text' => array(
				'label' => __('Slider Btn Text', 'unyson'),
				'type'  => 'text',
			),

			'slider_btn_url' => array(
				'label' => __('Slider Btn Url', 'unyson'),
				'type'  => 'text',
			),
			
		),


		
	),
);
