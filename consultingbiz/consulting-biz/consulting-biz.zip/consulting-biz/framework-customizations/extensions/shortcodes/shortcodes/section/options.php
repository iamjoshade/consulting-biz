<?php if (!defined('FW')) {
	die('Forbidden');
}

$options = array(
	'is_fullwidth' => array(
		'label'        => __('Container Fluid', 'consulting-biz'),
		'type'         => 'switch',
	),

	'is_row' => array(
		'label'        => __('Row', 'consulting-biz'),
		'type'         => 'switch',
	),

	'background_color' => array(
		'label' => __('Background Color', 'consulting-biz'),
		'desc'  => __('Please select the background color', 'consulting-biz'),
		'type'  => 'color-picker',
	),
	'background_image' => array(
		'label'   => __('Background Image', 'consulting-biz'),
		'desc'    => __('Please select the background image', 'consulting-biz'),
		'type'    => 'background-image',
		'choices' => array(//	in future may will set predefined images
		)
	),
	'video' => array(
		'label' => __('Background Video', 'consulting-biz'),
		'desc'  => __('Insert Video URL to embed this video', 'consulting-biz'),
		'type'  => 'text',
	),

	'custom_class' => array(
		'label' => __('Custom Class', 'consulting-biz'),
		'desc'  => __('Custom CSS Class Name', 'consulting-biz'),
		'type'  => 'text',
	),

);
