<?php if(!defined('FW')) die('forbidden');

$project_completed_text = $atts['project_completed_text'];
$project_completed_counter_number = $atts['project_completed_counter_number'];

$active_clients_text = $atts['active_clients_text'];
$active_clients_counter_number = $atts['active_clients_counter_number'];

$cups_of_coffee_text = $atts['cups_of_coffee_text'];
$cups_of_coffee_counter_number = $atts['cups_of_coffee_counter_number'];

$happy_clients_text = $atts['happy_clients_text'];
$happy_clients_counter_number = $atts['happy_clients_counter_number'];


$custom_class = $atts['custom_class'];

?>

      <!-- counter_area  -->
      <div class="container">
            <div class="row justify-content-between">
            <?php if (!empty($project_completed_text)): ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <!-- Counter Up -->
                    <div class="single-counter text-center">
                    <?php if (!empty($project_completed_counter_number)): ?>
                        <span class="counter"><?php echo $project_completed_counter_number;?></span>
                    <?php endif?>
                        <p><?php echo $project_completed_text?></p>
                    </div>
                </div>
                <?php endif;?>
                <?php if (!empty($active_clients_text)): ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <!-- Counter Up -->
                    <div class="single-counter active text-center">
                    <?php if (!empty($active_clients_counter_number)): ?>
                        <span class="counter"><?php echo $active_clients_counter_number;?></span>
                    <?php endif;?>
                        <p><?php echo $active_clients_text;?></p>
                    </div>
                </div>
                <?php endif;?>
                <?php if (!empty($cups_of_coffee_text)): ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <!-- Counter Up -->
                    <div class="single-counter text-center">
                    <?php if (!empty($cups_of_coffee_counter_number)): ?>
                        <span class="counter"><?php echo $cups_of_coffee_counter_number;?></span>
                    <?php endif;?>
                        <p><?php echo $cups_of_coffee_text;?></p>
                    </div>
                </div>
                <?php endif;?>
                <?php if (!empty($happy_clients_text)): ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <!-- Counter Up -->
                    <div class="single-counter text-center">
                    <?php if (!empty($happy_clients_counter_number)): ?>
                        <span class="counter"><?php echo $happy_clients_counter_number;?></span>
                    <?php endif;?>
                        <p><?php echo $happy_clients_text;?></p>
                    </div>
                </div>
                <?php endif;?>
            </div>
        </div>
    <!-- /counter_area  -->